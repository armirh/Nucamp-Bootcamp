#task2
# In donations_pkg/homepage.py, define a function named show_homepage()

def show_homepage():
    print("         === Donate Homepage ===")
    print("------------------------------------------")
    print("|1. Login             | 2. Register       |")
    print("|3. Donate            | 4. Show Donations |")
    print("---------------------------------------------")
    print("|               5. Exit                   |")
    print("---------------------------------------------")